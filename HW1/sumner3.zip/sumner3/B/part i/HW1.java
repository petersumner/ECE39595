public class HW1 {
    public static void main(String args[]) {
        Automobile car1 = new Automobile(1287, 160000, 5, 7, 2018);
        System.out.println(car1.toString( ));

        Automobile car2 = new Automobile(76, 47000, 12, 30, 2019);
        System.out.println(car2.toString( ));
    }
}