public class Automobile {

    private int idNumber;
    private float milesDriven;
    private String date;

    public Automobile(int _idNumber, float _milesDriven, int _month, int _day, int _year) {
        idNumber = _idNumber;
        milesDriven = _milesDriven;
        date = ""+_month+"/"+_day+"/"+_year;
    }

    public int getIdNumber( ) {
        return idNumber;
    }

    public void setIdNumber(int _idNumber) {
        idNumber = _idNumber;
    }

    public float getMilesDriven( ) {
        return milesDriven;
    }

    public void setMilesDriven(float _milesDriven) {
        milesDriven = _milesDriven;
    }

    public String getDate( ) {
        return date;
    }

    public void setDate(int _month, int _day, int _year) {
        date = ""+_month+"/"+_day+"/"+_year;
    }

    public String toString( ) {
        String automobile = idNumber+"\n";
        automobile += milesDriven+"\n";
        automobile += date+"\n";
        return automobile;
    }
}
